import json
import re

from ..base import GeoSQLBase, LLMBase
from ..exceptions import DependencyError
from httpx import Timeout


class Ollama(LLMBase):
    def __init__(self, config=None):

        try:
            ollama = __import__("ollama")
        except ImportError:
            raise DependencyError(
                "To execute this method, you need to install the required dependencies, run the following command:"
                " \npip install ollama"
            )

        if not config:
            raise ValueError("The configuration must contain at least the Ollama model")
        if 'model' not in config.keys():
            raise ValueError("The configuration must contain at least the Ollama model")

        self.host = config.get("ollama_host", "http://localhost:11434")
        self.model = config["model"]
        if ":" not in self.model:
            self.model += ":latest"

        self.ollama_timeout = config.get("ollama_timeout", 240.0)

        self.ollama_client = ollama.Client(self.host, timeout=Timeout(self.ollama_timeout))

        self.keep_alive = config.get('keep_alive', None)
        self.ollama_options = config.get('options', {})
        self.num_ctx=config.get('num_ctx',2048)
        self.__pull_model_if_ne(self.ollama_client, self.model)

    @staticmethod
    def __pull_model_if_ne(ollama_client, model):
        model_response = ollama_client.list()

        model_lists = [model_element['model'] for model_element in
                       model_response.get('models', [])]
        if model not in model_lists:
            ollama_client.pull(model)

    def system_message(self, message: str) -> any:
        """
        系统角色
        :param message: 请求信息
        :return:
        """
        return {"role": "system", "content": message}

    def user_message(self, message: str) -> any:
        """
        用户角色
        :param message:
        :return:
        """
        return {"role": "user", "content": message}

    def assistant_message(self, message: str) -> any:
        """
        助理角色
        :param message:
        :return:
        """
        return {"role": "assistant", "content": message}

    def extract_sql(self, llm_response):
        """
        从LLM返回语句中提取SQL
        :param llm_response:LLM返回信息
        :return: 找到的第一个 SQL 语句，删除三个反引号，如果未找到匹配项，则为空字符串。
        """

        # 删除ollama生成的多余字符
        # 清理 Ollama 中的特殊字符
        llm_response = llm_response.replace("\\_", "_").replace("\\", "")

        # 1. 优先匹配 ```sql ... ``` 块
        sql_block = re.search(r"```sql\s*\n(.*?)```", llm_response, re.DOTALL | re.IGNORECASE)

        if sql_block:
            return sql_block.group(1).strip()
        # 2. 其次尝试匹配 select/with 开头的 SQL，直到换行 + 空行 + 下一段文字或结束
        select_match = re.search(r"\b(select|with)\b[\s\S]{10,}?(?=\n\s*\n|$)", llm_response, re.IGNORECASE)

        if select_match:
            return select_match.group(0).strip()
        # 3. fallback：返回整体文本（不建议用于正式执行）
        return llm_response.strip()

    def submit_prompt(self, prompt, **kwargs) -> str:
        self.log(
            f"Ollama Parameters:\n"
            f"model={self.model},\n"
            f"options={self.ollama_options},\n"
            f"keep_alive={self.keep_alive}")
        try:
            response_dict = self.ollama_client.chat(model=self.model,
                                                    messages=prompt,
                                                    stream=False,
                                                    options=self.ollama_options,
                                                    keep_alive=self.keep_alive)
        except Exception as e:
            raise e
        return response_dict['message']['content']

    def frontend_generate_sql(self, prompt: list, stream: bool = True, **kwargs):
        """
        流式返回
        """
        self.log(
            f"Ollama Parameters:\n"
            f"model={self.model},\n"
            f"options={self.ollama_options},\n"
            f"keep_alive={self.keep_alive}")
        try:
            options = self.ollama_options.copy() if self.ollama_options is not None else {}
            options = {
                'num_predict': kwargs.get('max_tokens', self.num_ctx),
                'temperature': kwargs.get('temperature', 0),
                'top_p': kwargs.get('top_p', 1.0),
                'top_k': kwargs.get('top_k', 0),
                'stop': kwargs.get('stop', None),
            }
            response = self.ollama_client.chat(model=self.model,
                                               messages=prompt,
                                               stream=stream,
                                               options=options,
                                               keep_alive=self.keep_alive)
            buffer = ""
            for chunk in response:
                if not chunk['message']['content']:
                    continue  # 跳过空数据
                content = chunk['message']['content'] or ""
                buffer += content
                if len(buffer) >= 5:  # 只有在积累到 10 个字符后才发送
                    # SSE 格式要求 data: 前缀和双换行符
                    yield f"data: {json.dumps({'content': buffer})}\n\n"
                    buffer = ""
            if buffer:
                yield f"data: {json.dumps({'content': buffer})}\n\n"
        except Exception as e:
            self.log(title="[frontend_generate_sql][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"

