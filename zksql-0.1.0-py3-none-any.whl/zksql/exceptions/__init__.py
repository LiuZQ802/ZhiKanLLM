class DependencyError(Exception):
    """缺少依赖."""

    pass


class ValidationError(Exception):
    """验证错误"""

    pass

class ImproperlyConfigured(Exception):
    """配置错误"""

    pass
