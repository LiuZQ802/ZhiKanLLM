import os
import re
import json
import asyncio
import sqlparse
import numpy as np

from typing import AsyncGenerator
from ..base import LLMBase, RAGBase
from ..chromadb import ChromaDB_VectorStore
from ..exceptions import ImproperlyConfigured
from ..ollama import Ollama
from ..GPTAPI import GPTAPI



class SQLFrontend(LLMBase, RAGBase):

    def __init__(self, config,**kwargs):
        self.max_keep=3
        self.config = config
        self.rag_database = config.get("rag_database", 'chromadb')
        try:
            self.model_lists=config.get('model_lists')
        except Exception as e:
            raise 'Please configure the default model list'
        try:
            self.default_model=config.get('default_model')
        except Exception as e:
            raise 'Please configure the default model'
        if self.default_model not in self.model_lists:
            raise ValueError(f"Model '{self.default_model}' is not in the list of supported models: {self.model_lists}")
        try:
            self.llm_type = self.default_model['provider']  #获得模型提供商
        except Exception as e:
            raise 'Please configure the model provider, such as deepseek, ollama, etc.'
        self.__set_llm(self.llm_type, self.config)
        # self.__set_rag(self.rag_database)

        self.scene_map = self.__build_scene_map(config['sceneTablePath'])
    def __getattr__(self, name):
        # 检查是否存在该属性在rag中
        if hasattr(self.rag, name):
            return getattr(self.rag, name)
        # 检查是否存在该属性在llm中
        elif hasattr(self.llm, name):
            return getattr(self.llm, name)
        else:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
    """私有化set函数"""
    def __set_llm(self, llm_type:str, config):
        """设置llm"""
        if llm_type.lower() == 'ollama':
            config['ollama_host']=self.default_model.get('base_url','http://localhost:11434')
            try:
                config['model'] = self.default_model['model_name']
            except Exception as e:
                raise 'Please configure the model name'
            self.llm = Ollama(config=config)
        else:
            try:
                config['api_key']=self.default_model['api_key']
            except Exception as e:
                raise 'Please configure API KEY'
            try:
                config['base_url']=self.default_model['base_url']
            except Exception as e:
                raise 'Please configure Base URL'
            try:
                config['model']=self.default_model['model_name']
            except Exception as e:
                raise 'Please configure the model name'
            self.llm = GPTAPI(config=config)

    def __set_rag(self, rag_database):
        """设置rag"""
        if rag_database == 'chromadb':
            self.rag = ChromaDB_VectorStore(config=self.config)
        else:
            raise ImproperlyConfigured("Please configure the correct rag database!")
        
    def __build_scene_map(self,scene_table_path: str) -> dict:
        """
        从指定目录中读取所有 .sql 文件，构建 场景名称 -> 文件名 的映射字典。

        文件命名格式： 场景X-场景描述.sql
        """
        mapping = {}
        for fname in os.listdir(scene_table_path):
            if fname.endswith('.sql') and fname.startswith("场景"):
                match = re.match(r'^场景\d+-(.+?)\.sql$', fname)
                if match:
                    scene_name = match.group(1).strip()
                    mapping[scene_name] = fname
        return mapping
    
    """LLM、RAG等更新函数"""

    def update_llm_model(self, show_model_name):
        """更换LLM"""
        new_llm_model = [m for m in self.model_lists if m["show_name"] == show_model_name][0]
        self.default_model=new_llm_model  #更新默认模型配置
        self.llm_type = self.default_model['provider']
        self.__set_llm(self.llm_type,self.config)  # 通过私有方法重新设置LLM


    def update_rag(self, path):
        """更换RAG的path"""
        self.config['path'] = path
        self.__set_rag(self.rag_database)

    """参数信息GET函数"""

    def getAllModel(self) -> list:
        """所有模型"""
        # modelList = ['deepseek-r1:7b', 'deepseek-r1', 'gpt-3.5-turbo']
        modelList=[]
        for item in self.model_lists:
            try:
                modelList.append(item['show_name'])
            except Exception as e:
                modelList.append(item['model_name'])
        return modelList

    def getCurrentModel(self) -> str:
        """获得当前模型"""
        try:
            current_model=self.default_model['show_name']
        except Exception as e:
            current_model = self.default_model['model_name']
        return current_model

    def getAllDatabase(self) -> list:
        """所有数据库"""
        databasesList = ['sqlite', 'mysql', 'oracle', 'postgresql']
        return databasesList

    def getCurrentDatabase(self) -> (str, dict): # type: ignore
        """获得当前数据库"""
        return self.currentDatabase, self.currentDatabaseConfig

    def getAllRAGDatabase(self) -> list:
        """获取所有RAG向量库"""
        RAGDatabase = ['chromadb']
        return RAGDatabase

    def getCurrentRAGDatabase(self) -> str:
        """获取当前RAG向量库"""
        return self.rag_database

    def getCurrentRAGModel(self) -> str:
        """获取当前RAG检索模型"""
        return self.rag.getCurrentRAGModel()

    """RAG函数"""

    def retrieve_context(self, question: str, **kwargs) -> dict:
        """RAG检索相关信息"""
        return self.rag.retrieve_context(question, **kwargs)

    def add_ddl(self, ddl: str, tableInfo: str, **kwargs) -> str:
        return self.rag.add_ddl(ddl, tableInfo, **kwargs)

    def add_question_sql(self, question: str, sql: str, **kwargs) -> str:
        return self.rag.add_question_sql(question, sql, **kwargs)

    def add_documentation(self, documentation: str, **kwargs) -> str:
        return self.rag.add_documentation(documentation, **kwargs)

    def add_graph(self, graph: str, **kwargs) -> str:
        return self.rag.add_graph(graph, **kwargs)

    """LLM函数"""

    def system_message(self, message: str) -> any:
        return self.llm.system_message(message)

    def user_message(self, message: str) -> any:
        return self.llm.user_message(message)

    def assistant_message(self, message: str) -> any:
        return self.llm.assistant_message(message)

    def extract_sql(self, llm_response):
        return self.llm.extract_sql(llm_response)

    def submit_prompt(self, prompt, **kwargs) -> str:
        return self.llm.submit_prompt(prompt, **kwargs)

    """提供前端核心SQL生成及LLM响应函数"""

    def frontend_generate_sql(self, prompt: list, **kwargs):
        """返回前端生成SQL信息"""
        return self.llm.frontend_generate_sql(prompt, **kwargs)

    '''返回SQL问答'''
    #带rag
    async def return_frontend(self, question: str) -> AsyncGenerator[str, None]:
        """返回前端数据"""
        initial_prompt = self.config.get("initial_prompt") if self.config else None
        try:
            context = self.retrieve_context(question=question)  # 先检索
            prompt = self.construct_prompt(question=question, initial_prompt=initial_prompt,
                                           context=context)  # 生成prompt
            for sse_data in self.frontend_generate_sql(prompt=prompt):
                try:
                    data = sse_data[len("data: "):].strip()
                    json_data = json.loads(data)
                    if json_data.get('type', "") == 'error':
                        yield f"data: {json.dumps({'type': 'error', 'content': json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        return
                    else:
                        msg = f"data: {json.dumps({'type': 'result','content':json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        yield msg
                        await asyncio.sleep(0.01)
                except Exception as e:
                    self.log(title="[return_frontend][Warning]", message=f"无法解析的 SSE 数据: {sse_data}")
                    yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
                    return
            yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
        except Exception as e:
            self.log(title="[ask][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"

    '''返回LLM对话问答'''

    async def return_frontend_QA(self, question: str) -> AsyncGenerator[str, None]:
        """返回前端数据"""
        try:
            user_message = self.llm.user_message(question)  # 生成prompt
            system_message = self.llm.system_message('请回答下述问题')
            prompt = [system_message, user_message]
            for sse_data in self.frontend_generate_sql(prompt=prompt):
                try:
                    data = sse_data[len("data: "):].strip()
                    json_data = json.loads(data)
                    if json_data.get('type', '') == 'error':
                        yield f"data: {json.dumps({'type': 'error', 'content': json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        return
                    else:
                        msg = f"data: {json.dumps({'type': 'result','content':json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        yield msg
                        await asyncio.sleep(0.01)
                except Exception as e:
                    self.log(title="[return_frontend][Warning]", message=f"无法解析的 SSE 数据: {sse_data}")
                    yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
                    return
            yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"    
        except Exception as e:
            self.log(title="[ask][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"

    '''返回电力知识问答'''

    async def return_frontend_Knowledge_QA(self, question: str) -> AsyncGenerator[str, None]:
        """返回前端数据"""
        init_prompt = '''
            请根据下面电力知识回答相应问题：
            【电力知识】
            {}
            【问题】
            {}
        '''
        try:
            context = self.rag.get_related_documentation(question=question)  # 先检索
            init_prompt = init_prompt.format(context, question)
            user_message = self.llm.user_message(init_prompt)  # 生成prompt
            system_message = self.llm.system_message('你是一个电力知识专家，根据相关提示回答问题')
            prompt = [system_message, user_message]
            for sse_data in self.frontend_generate_sql(prompt=prompt):
                try:
                    data = sse_data[len("data: "):].strip()
                    json_data = json.loads(data)
                    if json_data.get('type', "") == 'error':
                        yield f"data: {json.dumps({'type': 'error', 'content': json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        return
                    else:
                        msg = f"data: {json.dumps({'type': 'result','content':json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        yield msg
                        await asyncio.sleep(0.01)
                except Exception as e:
                    self.log(title="[return_frontend][Warning]", message=f"无法解析的 SSE 数据: {sse_data}")
                    yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
                    return
            yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
        except Exception as e:
            self.log(title="[ask][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"

    '''返回RAG检索'''

    async def return_rag(self, question: str) -> AsyncGenerator[str, None]:
        """返回前端数据"""
        init_prompt = '''
                    请根据下面给出的信息，检索出和问题相关的知识，直接给出知识即可，如果全不相关，请返回【无】。不用多余废话：
                    【信息】
                    {}
                    【问题】
                    {}
                '''
        try:
            context = self.rag.get_related_documentation(question=question)  # 先检索
            init_prompt = init_prompt.format(context, question)
            user_message = self.llm.user_message(init_prompt)  # 生成prompt
            system_message = self.llm.system_message('你是检索专家，匹配所给知识和问题最匹配的一项')
            prompt = [system_message, user_message]
            for sse_data in self.frontend_generate_sql(prompt=prompt):
                try:
                    data = sse_data[len("data: "):].strip()
                    json_data = json.loads(data)
                    if json_data.get('type', "") == 'error':
                        yield f"data: {json.dumps({'type': 'error', 'content': json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        return
                    else:
                        msg = f"data: {json.dumps({'type': 'result','content':json_data.get('content', '')}, ensure_ascii=False)}\n\n"
                        yield msg
                        await asyncio.sleep(0.01)
                except Exception as e:
                    self.log(title="[return_frontend][Warning]", message=f"无法解析的 SSE 数据: {sse_data}")
                    yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
                    return
            yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
        except Exception as e:
            self.log(title="[ask][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
    
    '''流式返回JSON执行结果'''   
    async def generate_frontend_Data(self,llm_response:str) -> AsyncGenerator[str, None]:
        '''
        获得SQL执行的结果--流式
        '''
        sql = self.extract_sql(llm_response)
        try:
            results = self.run_sql(sql)
        except Exception as e:
            self.log(title="[generate_frontend_Data][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content':'SQL执行失败:'+str(e)})}\n\n"
            return
        # 发送表头（字段名列表）
        yield f"data: {json.dumps({'type': 'columns', 'columns': list(results.columns)})}\n\n"
        await asyncio.sleep(0.01)
        if results.empty:
            yield f"data: {json.dumps({'type': 'row', 'row': []})}\n\n"
            yield f"data: {json.dumps({'type': 'end'})}\n\n"
            return
        for row in results.itertuples(index=False):
            # if await request.is_disconnected():
            #     break
            row_data = list(row)
            yield f"data: {json.dumps({'type': 'row', 'row': row_data})}\n\n"
            await asyncio.sleep(0.01)
        yield f"data: {json.dumps({'type': 'end'})}\n\n"
    
    '''场景检索'''
    # 1、根据问题检索场景--返回LLM输出
    def __call_LLM_sceneRetrieval(self,question):
        #读取场景信息
        sceneMDPath=self.config['sceneMDPath']  #获得场景文档地址
        with open(sceneMDPath, 'r', encoding='utf-8') as f:
            sceneMDContent = f.read()
        # 3、如果问题不属于哪一个具体场景，可能涉及多个场景关键词，请回答我【场景组合】
        prompt = f"""
【所有场景信息】
{sceneMDContent}
【问题】
{question}
【任务要求】
请判断上方【问题】属于【所有场景信息】中的哪一个具体场景，并给出详细分析。回答内容需包括：
1. 识别问题所归属的唯一场景名称（仅使用已知的场景名称）
2. 简要说明为何该问题可以归类到该场景，要求语言清晰、自然、不分析字段；
3. 如果该问题可以实现查询，请继续说明实现思路（包括需要先查询哪些信息、后续处理方式等）

【输出格式要求】
输出内容仅允许采用以下两种格式之一：

【XXX】
该问题经过智能分析，判断其是要进行XXX。
若要实现该查询，首先需要查询什么信息，接着进行XXX操作。

【现阶段还无法解决该问题】
当前问题未能匹配至任何已知场景，可能是因为问题描述过于模糊、缺乏关键字段，或场景信息不完整。建议补充更多背景信息后重新尝试。

【注意事项】

- 输出必须严格遵循以上格式，包含中括号、换行和中文标点，不可改写；
- 所有场景是彼此独立、互不包含的，**禁止输出“属于 A 中的 B”或“结合多个场景”**这类说法；
- 场景描述可能不完整，有关键词就可以匹配，尽量匹配到所给的场景；
- 场景名称须与提供的场景一致，仅可选其一，禁止输出多场景或模糊判断；
- 不得分析字段名、代码或表结构，只允许自然语言推理；
- 禁止输出多种情况的组合或模糊判断结果。
- 请将【XXX】替换为实际匹配到的场景名称。直接回复场景名称即可，例如【馈线长度统计与分析】。
- 如果匹配到某个场景名称，后面必须跟着“该问题经过智能分析，判断其是要进行XXX。若要实现该查询，首先需要查询什么信息，接着进行XXX操作。”
- 输出示例：
    【馈线长度统计与分析】
    该问题经过智能分析，判断其是要进行馈线长度统计与分析。  
    若要实现该查询，首先需要查询各馈线的电压等级及其长度信息，接着按电压等级范围对馈线长度进行分组汇总统计。
"""
        message=[self.user_message(prompt)]
        results=self.submit_prompt(message)
        match = re.search(r'【(.*?)】', results)
        scene_name = match.group(1) if match else None
        results = results.replace(f"【{scene_name}】", "", 1).lstrip()
        return results,scene_name

    # 2、根据问题检索字段、表--返回LLM输出
    def __call_LLM_return_retrieval_table(self,question,scene_name):
        sceneTablePath = self.config['sceneTablePath']
        #提取场景
        scene_file = self.scene_map.get(scene_name)

        #判断是单一场景还是组合场景
        if scene_file:
            scenePath=os.path.join(sceneTablePath,scene_file)
            if os.path.exists(scenePath):
                with open(scenePath,'r',encoding='utf-8')as f:
                    ddlContent=f.read()
                prompt=f"""
                    【表结构】
                    {ddlContent}
                    【问题】
                    {question}
                    【注意】
                    1、请帮我检索如果根据该【问题】生成SQL的话。在给定表结构中，涉及到哪些表以及字段
                    2、返回我涉及到的表名-表中文名。不涉及的就不要返回了
                    3、返回我涉及到的字段名-字段中文名。不涉及的就不要返回了
                    4、仅返回2和3两项即可，不用返回其他的。
                    """
                message=[self.user_message(prompt)]
                results=self.submit_prompt(message)
                results=self.clean_llm_output(results)
                return results,ddlContent
    
    # 3、根据检索到的知识和字段生成SQL--返回LLM输出
    def __call_LLM_return_scene_SQL(self,question,sceneKnowledge,scene_name,tableInfo):
        sceneTablePath=self.config['sceneTablePath'] #场景表结构信息的base path
        #提取场景
        scene_file = self.scene_map.get(scene_name)
        ddlContent=''
        if scene_file:
            scenePath=os.path.join(sceneTablePath,scene_file)
            if os.path.exists(scenePath):
                with open(scenePath,'r',encoding='utf-8')as f:
                    ddlContent=f.read()
        prompt=f"""
                【问题】
                {question}
                【表结构信息】
                {ddlContent}
                【问题涉及的表以及字段】
                {tableInfo}
                【问题涉及到的知识】
                {sceneKnowledge}
                【生成要求】
                1. 请你根据上方的【问题】、【表结构信息】和【业务背景知识】，编写一条完整、严谨的 SQL 语句，用于在 Oracle 11g 数据库中执行。
                2. SQL 必须满足以下要求：
                    - 字段名称、表名称必须完全符合【表结构信息】中的定义；
                    - 使用标准的 Oracle 语法；
                    - 对于涉及时间、数值、空值处理的字段，必须使用合适函数；
                    - 如有多表查询，JOIN 条件必须明确，避免笛卡尔积；
                    - WHERE 子句要尽可能限制范围，防止全表扫描；
                    - GROUP BY、ORDER BY 必须合法；
                3. 只输出一段合法、格式化良好的 SQL 语句，不得添加任何解释、注释或多段 SQL。
                4. 严禁输出伪代码、模板语法或未经验证的字段。
                【输出格式】
                请只返回完整 SQL 语句，不包含说明、不换行注释、不解释语义。
        """
        message=[self.user_message(prompt)]
        results=self.submit_prompt(message)
        results=sqlparse.format(
                    results,
                    reindent=True,
                    keyword_case='upper'
                )
        return results

    # 4、多轮对话--返回LLM输出
    def __call_LLM_multiRounds(self,question,base_question,ddl,sql,history_prompt):
        prompt=f"""
                【基本问题】
                {base_question}
                【表结构信息】
                {ddl}
                【第一轮生成的SQL】
                {sql}
        """
        prompt+=history_prompt
        prompt += f"""
        【当前用户问题】
        {question}
        【生成要求】
1. 根据用户当前的问题结合上下文，理解用户意图；
2. 如果是对上一个 SQL 的修改、限定或拓展，应尽量基于已有 SQL；
3. 输出最终的 SQL 语句，保持语义准确；
4. 如无法判断或不确定，应明确指出问题模糊或上下文不足。
"""
        message=[self.user_message(prompt)]
        results=self.submit_prompt(message)
        results=sqlparse.format(
                    results,
                    reindent=True,
                    keyword_case='upper'
                )
        return results
        

    # 1、根据问题检索场景--流式返回
    async def sceneRetrieval(self,question):
        try:
            results,scene_name =self.__call_LLM_sceneRetrieval(question)
        except Exception as e:
            self.log(title="[sceneRetrieval][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            return
        self.log('INFO',results)
        async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name}):
            yield msg
        return
    # 2、根据问题检索字段、表--流式返回
    async def return_retrieval_table(self,question,scene_name):
        try:
            results,_=self.__call_LLM_return_retrieval_table(question,scene_name)
        except Exception as e:
            self.log(title="[sceneRetrieval][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            return
        self.log('INFO',results)
        async for msg in self.stream_by_chars(results,{'isNextStep':True}):
            yield msg

        #格式清除
    
    #清理LLM返回数据
    def clean_llm_output(self, text: str) -> str:
        text = re.sub(r'【.*?】', '', text)
        lines = [ line.strip() for line in text.splitlines() if line]
        text = '\n'.join(lines)
        return text.strip()

    
    # 3、根据检索到的知识和字段生成SQL--流式返回
    async def return_scene_SQL(self,question,sceneKnowledge,scene_name,tableInfo):
        try:
            results=self.__call_LLM_return_scene_SQL(question,sceneKnowledge,scene_name,tableInfo)
        except Exception as e:
            self.log(title="[sceneRetrieval][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            return
        self.log('INFO',results)
        async for msg in self.stream_by_chars(results,{'isNextStep':True}):
            yield msg
    
    '''根据数据和SQL返回图表'''
    def return_figure(self,llm_response):
        def convert_numpy(obj):
            if isinstance(obj, dict):
                return {k: convert_numpy(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy(i) for i in obj]
            elif isinstance(obj, tuple):
                return tuple(convert_numpy(i) for i in obj)
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            else:
                return obj     
        
        sql = self.extract_sql(llm_response)  #提取SQL
        results = self.run_sql(sql)  #执行SQL
        code = self.generate_plotly_code(sql=sql, df_metadata=results)  #请求LLM获得画图代码
        figure_dict = self.get_plotly_figure(code, results)  #执行代码
        if figure_dict is None:
            return None
        safe_content = convert_numpy(figure_dict.to_dict())
        return safe_content
    
    '''流程返回'''
    async def return_process(self,question:str):
        try:
            '''1、检索场景'''
            results,scene_name=self.__call_LLM_sceneRetrieval(question)
            self.log('INFO',results+scene_name)
            #如果检索不出来场景，直接结束
            if '现阶段还无法解决该问题' in scene_name:
                async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name,'current_step':'insight','next_step':'end'}):
                    yield msg
                yield f"data: {json.dumps({'type': 'interrupt'}, ensure_ascii=False)}\n\n"
                return 
            async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name,'current_step':'insight','next_step':'SchemaScan'}):
                yield msg
            '''2、检索表、字段'''
            results,_=self.__call_LLM_return_retrieval_table(question,scene_name)
            self.log('INFO',results)
            async for msg in self.stream_by_chars(results,{'isNextStep':True,'current_step':'SchemaScan','next_step':'SQLGen'}):
                yield msg
            '''3、生成SQL'''
            results=self.__call_LLM_return_scene_SQL(question,'',scene_name,results)
            self.log('INFO',results)
            async for msg in self.stream_by_chars(results,{'isNextStep':False,'current_step':'SQLGen','next_step':'end'}):
                yield msg
            '''end'''
            yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
        except Exception as e:
            self.log(title="[return_process][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            return

    '''多轮问答'''
    async def return_multiRounds_process(self,question,current_epoch,epoch):
        try:
            if current_epoch==1:
                self.history=[]  #第一轮对话，清空历史
                '''1、检索场景'''
                results,scene_name=self.__call_LLM_sceneRetrieval(question)
                self.log('INFO',results+scene_name)
                #如果检索不出来场景，直接结束
                if '现阶段还无法解决该问题' in scene_name:
                    async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name,'current_step':'insight','next_step':'end'}):
                        yield msg
                    yield f"data: {json.dumps({'type': 'interrupt'}, ensure_ascii=False)}\n\n"
                    return 
                if not results.strip():
                    results='现阶段还无法解决该问题，请修改您的输入信息。'
                    async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name,'current_step':'insight','next_step':'end'}):
                        yield msg
                    yield f"data: {json.dumps({'type': 'interrupt'}, ensure_ascii=False)}\n\n"
                    return 
                async for msg in self.stream_by_chars(results,{'isNextStep':True,'scene_name':scene_name,'current_step':'insight','next_step':'SchemaScan'}):
                    yield msg
                '''2、检索表、字段'''
                results,ddlContent=self.__call_LLM_return_retrieval_table(question,scene_name)
                self.log('INFO',results)
                async for msg in self.stream_by_chars(results,{'isNextStep':True,'current_step':'SchemaScan','next_step':'SQLGen'}):
                    yield msg
                '''3、生成SQL'''
                results=self.__call_LLM_return_scene_SQL(question,'',scene_name,results)
                self.log('INFO',results)
                async for msg in self.stream_by_chars(results,{'isNextStep':True,'current_step':'SQLGen','next_step':'end'}):
                    yield msg
                '''end'''
                yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
                #加入第一轮对话信息
                self.history.append({'question':question,'scene_name':scene_name,'ddl':ddlContent,'sql':results})
            else:
                if current_epoch>epoch:return #达到最大轮次
                base_question=self.history[0]['question']
                ddl=self.history[0]['ddl']
                base_sql=self.history[0]['sql']
                prompt=self.__history_splice()
                results=self.__call_LLM_multiRounds(question,base_question,ddl,base_sql,prompt)
                match = re.search(r"```sql[\s\S]*", results, re.IGNORECASE)
                results=match.group(0).strip() if match else results.strip()
                self.log('INFO',results)
                async for msg in self.stream_by_chars(results,{'isNextStep':True,'current_step':'SQLGen','next_step':'end'}):
                    yield msg
                yield f"data: {json.dumps({'type': 'end'}, ensure_ascii=False)}\n\n"
                #加入本轮对话信息
                self.history.append({'question':question,'answer':results})
        except Exception as e:
            self.log(title="[return_process][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            return
    
    #返回历史问题拼接
    def __history_splice(self):
        prompt=''
        tail = self.history[1:][-self.max_keep:]
        for idx,item in enumerate(tail,start=len(self.history) - len(tail) + 1):
            question=item['question']
            answer=item['answer']
            prompt+=f"""
            【第{idx}轮问题】
            {question}
            【第{idx}轮回答】
            {answer}
            """
        return prompt
    
    #流式返回
    async def stream_by_chars(self,text: str, additionInfo:dict,chunk_size: int = 10) -> AsyncGenerator[str, None]:
        """
        将输入文本每 chunk_size 个字符分块 yield 一次，模拟流式输出。

        参数：
            text (str): 要输出的完整文本
            chunk_size (int): 每次输出的字符数（默认10）

        返回：
            AsyncGenerator[str, None]
        """
        for i in range(0, len(text), chunk_size):
            chunk = text[i:i + chunk_size]
            if not chunk.strip():  # 如果全是空格或换行，跳过
                continue
            return_info = {'type': 'result', 'content': chunk,'current_step':additionInfo['current_step']}
            msg = f"data: {json.dumps(return_info, ensure_ascii=False)}\n\n"
            yield msg
            await asyncio.sleep(0.1)
        #阶段完成
        yield f"data: {json.dumps({'type': 'step_end','current_step':additionInfo['current_step'],'next_step':additionInfo['next_step']}, ensure_ascii=False)}\n\n"
        