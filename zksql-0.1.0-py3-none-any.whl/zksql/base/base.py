import os
import re
import sqlite3
import traceback
from abc import ABC, abstractmethod

from typing import List, Union, Tuple
from urllib.parse import urlparse

import pandas as pd
import plotly
import plotly.express as px
import plotly.graph_objects as go
import requests

from ..exceptions import ValidationError, DependencyError, ImproperlyConfigured
from ..gs_types import TrainingPlan, TrainingPlanItem


class GeoSQLBase(ABC):
    def __init__(self, config=None):
        if config is None:
            config = {}

        self.config = config  #配置文件
        self.run_sql_is_set = False
        self.currentDatabase = ''  #当前数据
        self.currentDatabaseConfig = {}  #当前数据库配置
        self.static_documentation = ""
        self.language = self.config.get("language", None)  #语言
        self.dialect = self.config.get("dialect", "SQL")  #数据库方言
        self.max_tokens = self.config.get("max_tokens", 14000)  #最大token

    def log(self, message: str, title: str = "Info"):
        print(f"{title}: {message}")

    def _response_language(self) -> str:
        if self.language is None:
            return ""

        return f"Respond in the {self.language} language."

    def generate_sql(self, prompt: str, **kwargs) -> tuple[str, str]:
        """
        根据问题生成SQL
        :param prompt:
        :param kwargs:
        :return:
        """

        llm_response = self.submit_prompt(prompt, **kwargs)
        self.log(title="LLM Response", message=llm_response)

        return llm_response, self.extract_sql(llm_response)

    def frontend_generate_sql(self, prompt: str, stream: bool = False, **kwargs):
        """
        生成给前端的sql及响应
        :param prompt:
        :param stream: 是否流式输出
        :param kwargs:
        :return:
        """
        pass

    def generate_intermediate_sql(self, prompt: str, allow_llm_to_see_data=False,
                                  **kwargs) -> str:
        if not allow_llm_to_see_data:
            return "LLM无法查看您数据库中的数据。您的问题需要数据库自检来生成必要的 SQL。请设置 allow_llm_to_see_data=True以启用此功能。"
        if allow_llm_to_see_data:
            try:
                self.log(title="Final SQL Prompt", message=prompt)
                llm_response = self.submit_prompt(prompt, **kwargs)
                self.log(title="LLM Response", message=llm_response)
            except Exception as e:
                return f"运行中间SQL时出错: {e}"
            return self.extract_sql(llm_response)

    def extract_sql(self, llm_response: str) -> str:
        """
        从LLM返回请求中提取SQL
        :param llm_response:
        :return:
        """
        #如果有think部分，现去除think
        llm_response = re.sub(r"<think>.*?</think>", "", llm_response, flags=re.DOTALL).strip()
        # If the llm_response contains a CTE (with clause), extract the last sql between WITH and ;
        sqls = re.findall(r"\bWITH\b .*?;", llm_response, re.DOTALL)
        if sqls:
            sql = sqls[-1]
            self.log(title="Extracted SQL", message=f"{sql}")
            return sql

        # If the llm_response is not markdown formatted, extract last sql by finding select and ; in the response
        sqls = re.findall(r"SELECT.*?;", llm_response, re.DOTALL)
        if sqls:
            sql = sqls[-1]
            self.log(title="Extracted SQL", message=f"{sql}")
            return sql

        # If the llm_response contains a markdown code block, with or without the sql tag, extract the last sql from it
        sqls = re.findall(r"```sql\n(.*)```", llm_response, re.DOTALL)
        if sqls:
            sql = sqls[-1]
            self.log(title="Extracted SQL", message=f"{sql}")
            return sql

        sqls = re.findall(r"```(.*)```", llm_response, re.DOTALL)
        if sqls:
            sql = sqls[-1]
            self.log(title="Extracted SQL", message=f"{sql}")
            return sql

        return llm_response

    # ----------------- 数据处理 ----------------- #
    def __extract_info(self, ddl: str) -> list[dict]:
        """
        从数据库建表语句中提出关键信息：表名、字段、主外键等
        :param ddl:
        :return: [{},{}]表信息数组
        """
        # 抽取 create table 结构
        table_pattern = re.compile(r"create table (\w+)\s*\((.*?)\);", re.S | re.I)
        comment_table_pattern_template = r"comment on table {} is\s*'([^']*)';"
        comment_column_pattern_template = r"comment on column {}\.(\w+) is\s*'([^']*)';"
        foreign_key_pattern_template = r"alter table\s+{}\s+add constraint\s+(\w+)\s+foreign key\s*\((\w+)\)\s+references\s+(\w+)\s*\((\w+)\);"
        pk_pattern_template = r"alter\s+table\s+{}\s+add\s+constraint\s+\w+\s+primary\s+key\s*\(([\w,\s]+)\);"

        table_info = []  # 所有表结构信息
        for table in table_pattern.finditer(ddl):
            table_item = {
                "table_name": "",
                "table_cn_name": "",
                "isHaveForeignKey": False,
                "fields": []
            }
            table_name, body = table.groups()
            table_item["table_name"] = table_name
            field_lines = [line.strip() for line in body.strip().split(",\n")]
            field_map = {}
            pk_fields = []
            for line in field_lines:
                line = line.strip()
                if line.lower().startswith("constraint") and "primary key" in line.lower():
                    # 提取括号里的字段
                    m = re.search(r"primary key\s*\((.*?)\)", line, re.I)
                    if m:
                        pk_fields += [f.strip() for f in m.group(1).split(",")]
                    continue  # 约束行不用当字段

                parts = line.split()
                if len(parts) >= 2:
                    field_name = parts[0]
                    field_type = parts[1]
                    field_map[field_name] = {
                        "field_name": field_name,
                        "field_cn_name": "",
                        "field_type": field_type,
                        "isPrimaryKey": False,
                        "isForeignKey": False,
                        "description": ""
                    }
            # 提取表注释
            comment_table_pattern = re.compile(comment_table_pattern_template.format(re.escape(table_name)),
                                               re.I | re.S)
            for comment in comment_table_pattern.findall(ddl):
                table_item["table_cn_name"] = comment
            # 提取字段中文名
            comment_column_pattern = re.compile(comment_column_pattern_template.format(re.escape(table_name)), re.I)
            for field, comment in comment_column_pattern.findall(ddl):
                if field in field_map:
                    field_map[field]["field_cn_name"] = comment
                    field_map[field]["description"] = comment
            # 提取外键
            foreign_key_pattern = re.compile(foreign_key_pattern_template.format(re.escape(table_name)), re.I)
            fk_tracker = {}
            for _, fk_field, ref_table, ref_field in foreign_key_pattern.findall(ddl):
                table_item["isHaveForeignKey"] = True
                if fk_field not in fk_tracker:
                    fk_tracker[fk_field] = []
                fk_tracker[fk_field].append((ref_table, ref_field))
            for fk_field, refs in fk_tracker.items():
                if fk_field in field_map:
                    field_map[fk_field]["isForeignKey"] = True
                    field_map[fk_field]["relationTables"] = ",".join([r[0] for r in refs])
                    field_map[fk_field]["relationFields"] = ",".join([r[1] for r in refs])

            # 提取主键
            pk_pattern = re.compile(pk_pattern_template.format(re.escape(table_name)), re.I)
            for pk_field in pk_pattern.findall(ddl):
                if pk_field in field_map:
                    field_map[pk_field]["isPrimaryKey"] = True
            for pk_field in pk_fields:
                if pk_field in field_map:
                    field_map[pk_field]["isPrimaryKey"] = True
            table_item["fields"] = list(field_map.values())
            table_info.append(table_item)
        return table_info

    def __create_tableInfo_prompt(self, table: dict) -> str:
        """
        构建表结构的嵌入信息
        :param table:
        :return:
        """
        table_name = table.get("table_name", "")
        table_cn_name = table.get("table_cn_name", "")
        table_description = '该表主要包括'
        primary_keys = []
        foreign_keys = []
        fields_name = []
        fields_cn_name = []
        fields_type = []
        fields_description = []
        for field in table.get("fields", []):
            fields_name.append(field.get('field_name', ''))
            fields_cn_name.append(field.get('field_cn_name', ''))
            fields_type.append(field.get('field_type', ''))
            fields_description.append(field.get('description', ''))
            if field.get("isPrimaryKey", False):
                primary_keys.append(f"{field['field_name']}：{field['field_cn_name']}")
            if field.get("isForeignKey", False):
                field_name = field.get("field_name", "")
                field_cn_name = field.get("field_cn_name", "")
                relation_tables = field.get("relationTables", "")
                relation_fields = field.get("relationFields", "")
                tables = relation_tables.split(",") if relation_tables else []
                fields = relation_fields.split(",") if relation_fields else []
                relation_list = []
                for t, f in zip(tables, fields):
                    relation_list.append(f"{t}.{f}字段")
                if relation_list:
                    relation_str = "和".join(relation_list)
                    fk_info = f"{field_name}字段外键关联到{relation_str}"
                    foreign_keys.append(fk_info)
        primary_key_str = "；".join(primary_keys) or "无主键"
        foreign_key_str = "；".join(foreign_keys) or "无外键"
        fields_str = "\n".join(f"""{field_name}:{field_cn_name},类型是{field_type}，字段描述：{field_description}""" for
                               field_name, field_cn_name, field_type, field_description in
                               zip(fields_name, fields_cn_name, fields_type, fields_description))
        fields_info = \
            f"""
表名:{table_name}
表中文名：{table_cn_name}
字段信息:
{fields_str}
主键字段：
{primary_key_str}
外键字段：
{foreign_key_str}"""
        return fields_info

    def __create_embed(self, table: dict, exclude_field: list = None) -> str:
        """
        从DDL语句中抽离出向量结构
        :param exclude_field:
        :param table:
        :return:
        """
        if exclude_field is None:
            exclude_field=[]
        concept_path = " > ".join(table.get("concept_path", []))  # + "\n" + doc["description"]
        table_name = table.get("table_name", "")
        table_cn_name = table.get("table_cn_name", "")
        description = '该表主要包括'
        # 主键和外键信息提取
        primary_keys = []
        foreign_keys = []
        fields_cn_name = []
        for field in table.get("fields", []):
            if field.get('field_cn_name', '') in exclude_field:
                continue
            fields_cn_name.append(field.get('field_cn_name', ''))
            if field.get("isPrimaryKey", False):
                primary_keys.append(f"{field['field_name']}--{field['field_cn_name']}")
            if field.get("isForeignKey", False):
                field_name = field.get("field_name", "")
                field_cn = field.get("field_cn_name", "")
                relation_tables = field.get("relationTables", "")
                relation_fields = field.get("relationFields", "")
                tables = relation_tables.split(",") if relation_tables else []
                fields = relation_fields.split(",") if relation_fields else []
                relation_list = []
                for t, f in zip(tables, fields):
                    relation_list.append(f"{t}表的{f}字段")
                if relation_list:
                    relation_str = " 和 ".join(relation_list)
                    fk_info = f"{field_name}（{field_cn}）该外键关联到{relation_str}"
                    foreign_keys.append(fk_info)
        primary_key_str = "；".join(primary_keys) or "无主键"
        foreign_key_str = "；".join(foreign_keys) or "无外键"
        description += '、'.join(filter(None, fields_cn_name)) + '等字段'
        # 构造嵌入文本
        embed_text = "\n".join(filter(None, [
            f"表名：{table_cn_name}" if table_cn_name else "",
            f"概念路径：{concept_path}" if concept_path else "",
            f"简要描述：{description}" if description else "",
            f"主键字段：{primary_key_str}" if primary_key_str else "",
            f"外键字段：{foreign_key_str}" if foreign_key_str else "",
        ])).strip()

        return embed_text

    # ----------------- 使用任意的Embeddings模型 ----------------- #
    @abstractmethod
    def generate_embedding(self, data: str, **kwargs) -> List[float]:
        pass
    @abstractmethod
    def chunk_text(self, text_list, chunk_size=300):
        """对documentation进行分块"""
        pass
    # ----------------- 使用任何数据库来存储和检索上下文 ----------------- #
    @abstractmethod
    def get_similar_question_sql(self, question: str, **kwargs) -> list:
        """
        This method is used to get similar questions and their corresponding SQL statements.

        Args:
            question (str): The question to get similar questions and their corresponding SQL statements for.

        Returns:
            list: A list of similar questions and their corresponding SQL statements.
        """
        pass

    @abstractmethod
    def get_related_documentation(self, question: str, **kwargs) -> list:
        """
        This method is used to get related documentation to a question.

        Args:
            question (str): The question to get related documentation for.

        Returns:
            list: A list of related documentation.
        """
        pass

    @abstractmethod
    def get_related_ddl(self, question: str, **kwargs) -> list:
        pass

    @abstractmethod
    def retrieve_context(self, question: str, **kwargs) -> dict:
        pass

    @abstractmethod
    def add_question_sql(self, question: str, sql: str, **kwargs) -> str:
        """
        This method is used to add a question and its corresponding SQL query to the training data.

        Args:
            question (str): The question to add.
            sql (str): The SQL query to add.

        Returns:
            str: The ID of the training data that was added.
        """
        pass

    @abstractmethod
    def add_documentation(self, documentation: str, **kwargs) -> str:
        """
        This method is used to add documentation to the training data.

        Args:
            documentation (str): The documentation to add.

        Returns:
            str: The ID of the training data that was added.
        """
        pass

    @abstractmethod
    def add_ddl(self, ddl: str, tableInfo: str, **kwargs) -> str:
        pass

    @abstractmethod
    def add_graph(self, graph: str, **kwargs) -> str:
        pass

    @abstractmethod
    def get_training_data(self, **kwargs) -> pd.DataFrame:
        """
        Example:
        ```python
        ```

        This method is used to get all the training data from the retrieval layer.

        Returns:
            pd.DataFrame: The training data.
        """
        pass

    @abstractmethod
    def remove_training_data(self, id: str, **kwargs) -> bool:
        """
        Example:
        ```python
        remove_training_data(id="123-ddl")
        ```

        This method is used to remove training data from the retrieval layer.

        Args:
            id (str): The ID of the training data to remove.

        Returns:
            bool: True if the training data was removed, False otherwise.
        """
        pass

    # ----------------- 使用任意的LLM ----------------- #
    @abstractmethod
    def system_message(self, message: str) -> any:
        pass

    @abstractmethod
    def user_message(self, message: str) -> any:
        pass

    @abstractmethod
    def assistant_message(self, message: str) -> any:
        pass

    @abstractmethod
    def submit_prompt(self, prompt, **kwargs) -> str:
        """
        Example:
        ```python
        submit_prompt(
            [
                system_message("The user will give you SQL and you will try to guess what the business question this query is answering. Return just the question without any additional explanation. Do not reference the table name in the question."),
                user_message("What are the top 10 customers by sales?"),
            ]
        )
        ```

        This method is used to submit a prompt to the LLM.

        Args:
            prompt (any): The prompt to submit to the LLM.

        Returns:
            str: The response from the LLM.
        """
        pass

    def str_to_approx_token_count(self, string: str) -> int:
        """
        计算token
        :param string:
        :return:
        """
        return len(string) // 4

    def add_ddl_to_prompt(
            self, initial_prompt: str, ddl_list: list[str], max_tokens: int = 14000
    ) -> str:
        """
        将检索到的表结构加入prompt
        :param initial_prompt:
        :param ddl_list:
        :param max_tokens:
        :return:
        """
        if len(ddl_list) > 0:
            initial_prompt += "\n【表结构如下：】 \n"
            for index, ddl in enumerate(ddl_list):
                if self.str_to_approx_token_count(initial_prompt) + self.str_to_approx_token_count(ddl) < max_tokens:
                    initial_prompt += f"{str(index + 1)}." + ddl + "\n"
        return initial_prompt

    def add_documentation_to_prompt(
            self,
            initial_prompt: str,
            documentation_list: list[str],
            max_tokens: int = 14000,
    ) -> str:
        """
        将检索到的相关文档嵌入prompt
        :param initial_prompt:
        :param documentation_list:
        :param max_tokens:
        :return:
        """
        if len(documentation_list) > 0:
            initial_prompt += "\n【补充信息】 \n\n"
            for doc in documentation_list:
                if self.str_to_approx_token_count(initial_prompt) + self.str_to_approx_token_count(doc) < max_tokens:
                    initial_prompt += f"{doc}\n\n"
        return initial_prompt

    def add_sql_to_prompt(
            self, initial_prompt: str, sql_list: list[str], max_tokens: int = 14000
    ) -> str:
        """
        将检索到的问题SQL对嵌入prompt
        :param initial_prompt:
        :param sql_list:
        :param max_tokens:
        :return:
        """
        if len(sql_list) > 0:
            initial_prompt += "\n【问题-SQL对示例】\n\n"
            for question in sql_list:
                if self.str_to_approx_token_count(initial_prompt) + self.str_to_approx_token_count(
                        question) < max_tokens:
                    initial_prompt += f"问题：{question['quesion']}\nSQL{question['sql']}\n"
        return initial_prompt

    def get_sql_prompt(
            self,
            initial_prompt: str,
            question: str,
            question_sql_list: list,
            ddl_list: list,
            doc_list: list,
            **kwargs,
    ):
        """
        Example:
        ```python
        get_sql_prompt(
            question="What are the top 10 customers by sales?",
            question_sql_list=[{"question": "What are the top 10 customers by sales?", "sql": "SELECT * FROM customers ORDER BY sales DESC LIMIT 10"}],
            ddl_list=["CREATE TABLE customers (id INT, name TEXT, sales DECIMAL)"],
            doc_list=["The customers table contains information about customers and their sales."],
        )
        ```
        This method is used to generate a prompt for the LLM to generate SQL.
        Args:
            question (str): The question to generate SQL for.
            question_sql_list (list): A list of questions and their corresponding SQL statements.
            ddl_list (list): A list of DDL statements.
            doc_list (list): A list of documentation.
        Returns:
            any: The prompt for the LLM to generate SQL.
        """
        # message_log=[]
        if initial_prompt is None:
            initial_prompt = f"你是一个{self.dialect}专家，请协助生成 SQL 查询来回答该问题。您的回复应仅基于给定的上下文，并遵循回复指南和格式说明。"
        message_log = [self.system_message(initial_prompt)]
        initial_prompt = self.add_ddl_to_prompt('', ddl_list, max_tokens=self.max_tokens)
        if self.static_documentation != "":
            doc_list.append(self.static_documentation)
        initial_prompt = self.add_documentation_to_prompt(initial_prompt, doc_list, max_tokens=self.max_tokens)
        initial_prompt += (
            "【回复指南】 \n"
            "1. 仅使用提供的表结构信息，严禁使用不存在的表或字段.禁止编造表名、字段名或关系\n"
            "2. 请优先依据“表中文名”匹配问题中的关键词，确定查询主表\n"
            "3. 如果提供的上下文足够，请生成一个有效的 SQL 查询，无需对问题进行任何解释。\n"
            "4. 如果提供的上下文基本足够，但需要了解特定列中的特定字符串，请生成一个中间 SQL 查询来查找该列中的不同字符串。请在查询前面添加“intermediate_sql”注释。\n"
            "5. 如果提供的上下文不足，请解释无法生成的原因。\n"
            "7. 如果该问题之前已被提出并得到解答，请准确重复之前的答案。\n"
            f"8. 确保输出 SQL 符合 {self.dialect} 且可执行，并且没有语法错误。\n"
            "9. 最终输出SQL查询语句，严格根据问题输出，不要输出额外解释\n"
        )

        for example in question_sql_list:
            if example is None:
                self.log(title="[get_sql_prompt][Warning]", message="example is None")
            else:
                if example is not None and "question" in example and "sql" in example:
                    message_log.append(self.user_message(example["question"]))
                    message_log.append(self.system_message(example["sql"]))
        initial_prompt += f"【问题】\n{question}"
        message_log.append(self.user_message(initial_prompt))
        return message_log

    def construct_prompt(
            self,
            question: str,
            initial_prompt: str = None,
            context: dict = None,
            **kwargs
    ):
        """
        根据问题检索相关向量，然后生成相关prompt
        :param context:
        :param question:
        :param kwargs:
        :return:
        """
        if context is None:
            context = {}
        question_sql_list = context.get("question_sql_list", [])
        ddl_list = context.get("ddl_list", [])
        doc_list = context.get("doc_list", [])
        prompt = self.get_sql_prompt(
            initial_prompt=initial_prompt,
            question=question,
            question_sql_list=question_sql_list,
            ddl_list=ddl_list,
            doc_list=doc_list,
            **kwargs,
        )
        return prompt

    def _extract_python_code(self, markdown_string: str) -> str:
        # Strip whitespace to avoid indentation errors in LLM-generated code
        markdown_string = markdown_string.strip()

        # Regex pattern to match Python code blocks
        pattern = r"```[\w\s]*python\n([\s\S]*?)```|```([\s\S]*?)```"

        # Find all matches in the markdown string
        matches = re.findall(pattern, markdown_string, re.IGNORECASE)

        # Extract the Python code from the matches
        python_code = []
        for match in matches:
            python = match[0] if match[0] else match[1]
            python_code.append(python.strip())

        if len(python_code) == 0:
            return markdown_string

        return python_code[0]

    def _sanitize_plotly_code(self, raw_plotly_code: str) -> str:
        # Remove the fig.show() statement from the plotly code
        plotly_code = raw_plotly_code.replace("fig.show()", "")

        return plotly_code

    def generate_plotly_code(
            self, question: str = None, sql: str = None, df_metadata: str = None, **kwargs
    ) -> str:
        if question is not None:
            system_msg = f"以下是一个pandas DataFrame，其中包含回答用户提出的问题的查询结果: '{question}'"
        else:
            system_msg = "以下是pandas DataFrame"

        if sql is not None:
            system_msg += f"\n\n使用以下查询生成 DataFrame： {sql}\n\n"

        system_msg += f"以下是有关生成的 pandas DataFrame 'df' 的信息: \n{df_metadata}"

        message_log = [
            self.system_message(system_msg),
            self.user_message(
                "你能生成 Python plotly 代码来绘制数据框的结果吗？假设数据位于名为“df”的 pandas 数据框中。如果数据框中只有一个值，请使用指示器。请仅使用 Python 代码进行回答。不要提供任何解释，只需提供代码即可。"
            ),
        ]

        plotly_code = self.submit_prompt(message_log, kwargs=kwargs)

        return self._sanitize_plotly_code(self._extract_python_code(plotly_code))

    # ----------------- 连接数据库并执行SQL语句 ----------------- #

    def connect_to_sqlite(self, url: str, check_same_thread: bool = False, **kwargs):
        """
        连接sqlite数据库
        :param url:
        :param check_same_thread:
        :param kwargs:
        :return:
        """
        path = os.path.basename(urlparse(url).path)
        if not os.path.exists(url):
            response = requests.get(url)
            response.raise_for_status()  #检查连接是否成功
            with open(path, "wb") as f:
                f.write(response.content)
            url = path
        conn = sqlite3.connect(url, check_same_thread=check_same_thread, **kwargs)

        def run_sql_sqlite(sql: str):
            return pd.read_sql_query(sql, conn)

        self.dialect = "SQLite"
        self.currentDatabase = 'sqlite'
        self.currentDatabaseConfig = {'url': url}
        self.run_sql = run_sql_sqlite
        self.run_sql_is_set = True

    def connect_to_mysql(
            self,
            host: str = None,
            dbname: str = None,
            user: str = None,
            password: str = None,
            port: int = None,
            **kwargs
    ):
        """
        连接mysql数据库
        :param host:
        :param dbname:
        :param user:
        :param password:
        :param port:
        :param kwargs:
        :return:
        """
        try:
            import pymysql.cursors
        except ImportError:
            raise DependencyError(
                "您需要安装所需的依赖项才能执行此方法，,"
                " 运行命令: \npip install PyMySQL"
            )
        if not host:
            host = os.getenv("HOST")
        if not host:
            raise ImproperlyConfigured("请设置MySQL数据库的host")
        if not dbname:
            dbname = os.getenv("DATABASE")
        if not dbname:
            raise ImproperlyConfigured("请设置MySQL的database")
        if not user:
            user = os.getenv("USER")
        if not user:
            raise ImproperlyConfigured("请设置MySQL的user")
        if not password:
            password = os.getenv("PASSWORD")

        if not password:
            raise ImproperlyConfigured("请设置MySQL的password")

        if not port:
            port = os.getenv("PORT")

        if not port:
            raise ImproperlyConfigured("请设置MySQL的port")

        conn = None

        try:
            conn = pymysql.connect(
                host=host,
                user=user,
                password=password,
                database=dbname,
                port=port,
                cursorclass=pymysql.cursors.DictCursor,
                **kwargs
            )
        except pymysql.Error as e:
            raise ValidationError(e)

        def run_sql_mysql(sql: str) -> Union[pd.DataFrame, None]:
            if conn:
                try:
                    conn.ping(reconnect=True)
                    cs = conn.cursor()
                    cs.execute(sql)
                    results = cs.fetchall()
                    df = pd.DataFrame(
                        results, columns=[desc[0] for desc in cs.description]
                    )
                    return df
                except pymysql.Error as e:
                    conn.rollback()
                    raise ValidationError(e)
                except Exception as e:
                    conn.rollback()
                    raise e

        self.run_sql_is_set = True
        self.currentDatabase = 'mysql'
        self.currentDatabaseConfig = {'host': host, 'user': user, 'password': password, 'port': port}
        self.run_sql = run_sql_mysql

    def connect_to_oracle(
            self,
            user: str = None,
            password: str = None,
            dsn: str = None,
            **kwargs
    ):
        """
        连接到orcale数据库
        :param user:
        :param password:
        :param dsn:
        :param kwargs:
        :return:
        """
        try:
            import oracledb
        except ImportError:

            raise DependencyError(
                "您需要安装所需的依赖项才能执行此方法,"
                "运行命令: \npip install oracledb"
            )
        if not dsn:
            dsn = os.getenv("DSN")
        if not dsn:
            raise ImproperlyConfigured("请设置Oracle dsn，其中应包括host:port/sid")

        if not user:
            user = os.getenv("USER")

        if not user:
            raise ImproperlyConfigured("请设置Oracle的数据库user")

        if not password:
            password = os.getenv("PASSWORD")

        if not password:
            raise ImproperlyConfigured("请设置Oracle的Oracle数据库password")

        conn = None
        try:
            conn = oracledb.connect(
                user=user,
                password=password,
                dsn=dsn,
                **kwargs
            )
        except oracledb.DatabaseError as e:
            error_text = str(e)
            # 如果遇到 thin mode 不支持的错误
            if "DPY-3010" in error_text:
                self.log(title="[connect_to_oracle][Warning]",
                         message="当前服务器版本过老，自动切换到 thick 模式连接...")
                # 尝试切换 thick 模式
                try:
                    # 这里默认你 Instant Client 放在这个路径
                    oracledb.init_oracle_client()
                except Exception as e2:
                    raise Exception(f"切换thick模式失败，请确认Instant Client安装正确: {e2}")

                # 再连一次
                conn = oracledb.connect(
                    user=user,
                    password=password,
                    dsn=dsn,
                    **kwargs
                )
            else:
                raise e
        except oracledb.Error as e:
            raise ValidationError(e)

        def run_sql_oracle(sql: str) -> Union[pd.DataFrame, None]:
            if conn:
                try:
                    sql = sql.rstrip()
                    if sql.endswith(';'):
                        sql = sql[:-1]
                    cs = conn.cursor()
                    cs.execute(sql)
                    results = cs.fetchall()

                    df = pd.DataFrame(
                        results, columns=[desc[0] for desc in cs.description]
                    )
                    return df
                except oracledb.Error as e:
                    conn.rollback()
                    raise ValidationError(e)

                except Exception as e:
                    conn.rollback()
                    raise e

        self.run_sql_is_set = True
        self.currentDatabase = 'oracle'
        self.currentDatabaseConfig = {'user': user, 'password': password, 'dsn': dsn}
        self.run_sql = run_sql_oracle

        self.log(message="Oracle数据库连接成功!!")

    def connect_to_postgres(
            self,
            host: str = None,
            dbname: str = None,
            user: str = None,
            password: str = None,
            port: int = None,
            **kwargs
    ):
        """
        连接postgres
        :param host:
        :param dbname:
        :param user:
        :param password:
        :param port:
        :param kwargs:
        :return:
        """
        try:
            import psycopg2
            import psycopg2.extras
        except ImportError:
            raise DependencyError(
                "您需要安装所需的依赖项才能执行此方法，"
                "运行命令: \npip install vanna[postgres]"
            )
        if not host:
            host = os.getenv("HOST")

        if not host:
            raise ImproperlyConfigured("请设置postgres host")

        if not dbname:
            dbname = os.getenv("DATABASE")

        if not dbname:
            raise ImproperlyConfigured("请设置postgres database")

        if not user:
            user = os.getenv("PG_USER")

        if not user:
            raise ImproperlyConfigured("请设置postgres user")

        if not password:
            password = os.getenv("PASSWORD")

        if not password:
            raise ImproperlyConfigured("请设置postgres password")

        if not port:
            port = os.getenv("PORT")

        if not port:
            raise ImproperlyConfigured("请设置postgres port")

        conn = None

        try:
            conn = psycopg2.connect(
                host=host,
                dbname=dbname,
                user=user,
                password=password,
                port=port,
                **kwargs
            )
        except psycopg2.Error as e:
            raise ValidationError(e)

        def connect_to_db():
            return psycopg2.connect(host=host, dbname=dbname,
                                    user=user, password=password, port=port, **kwargs)

        def run_sql_postgres(sql: str) -> Union[pd.DataFrame, None]:
            conn = None
            try:
                conn = connect_to_db()  # Initial connection attempt
                cs = conn.cursor()
                cs.execute(sql)
                results = cs.fetchall()

                # Create a pandas dataframe from the results
                df = pd.DataFrame(results, columns=[desc[0] for desc in cs.description])
                return df

            except psycopg2.InterfaceError as e:
                # Attempt to reconnect and retry the operation
                if conn:
                    conn.close()  # Ensure any existing connection is closed
                conn = connect_to_db()
                cs = conn.cursor()
                cs.execute(sql)
                results = cs.fetchall()

                # Create a pandas dataframe from the results
                df = pd.DataFrame(results, columns=[desc[0] for desc in cs.description])
                return df
            except psycopg2.Error as e:
                if conn:
                    conn.rollback()
                    raise ValidationError(e)

            except Exception as e:
                conn.rollback()
                raise e

        self.dialect = "PostgreSQL"
        self.run_sql_is_set = True
        self.currentDatabase = 'postgressql'
        self.currentDatabaseConfig = {'host': host, 'dbname': dbname, 'user': user, 'password': password, 'port': port}
        self.run_sql = run_sql_postgres

    # ----------------- 基本函数 ----------------- #
    def getAllDatabase(self) -> list:
        """所有数据库"""
        pass

    def getAllModel(self) -> list:
        """所有模型"""
        pass

    def getAllRAGDatabase(self) -> list:
        """获取所有RAG向量库"""
        pass

    def getCurrentDatabase(self) -> [str, dict]:
        """获得当前数据库"""
        pass

    def getCurrentRAGDatabase(self) -> str:
        """获取当前RAG向量库"""
        pass

    def getCurrentRAGModel(self) -> str:
        """获取当前RAG检索模型"""
        pass

    def run_sql(self, sql: str, **kwargs) -> pd.DataFrame:
        """
        Example:
        ```python
        vn.run_sql("SELECT * FROM my_table")
        ```

        Run a SQL query on the connected database.

        Args:
            sql (str): The SQL query to run.

        Returns:
            pd.DataFrame: The results of the SQL query.
        """
        raise Exception(
            "You need to connect to a database first by running connect_to_snowflake(), connect_to_postgres(), "
            "similar function, or manually set run_sql"
        )

    def predict(self, prompt: str, allow_llm_to_see_data: bool = False, ) -> tuple[str, str]:
        step1_llm_response, sql = self.generate_sql(prompt=prompt)  # 生成SQL
        # return step1_llm_response, sql
        return sql

    def return_frontend(self, question: str) -> str:
        '''返回前端响应'''
        pass

    def ask(
            self,
            question: Union[str, None] = None,
            print_results: bool = True,
            auto_train: bool = True,
            visualize: bool = True,  # if False, will not generate plotly code
            allow_llm_to_see_data: bool = False,
    ) -> Union[
        Tuple[
            Union[str, None],
            Union[pd.DataFrame, None],
            Union[plotly.graph_objs.Figure, None],
        ],
        None,
    ]:
        """
        提问
        :param question:
        :param print_results:
        :param auto_train:
        :param visualize:
        :param allow_llm_to_see_data:
        :return:
        """
        if question is None:
            question = input("Enter a question: ")
        if self.config is not None:
            initial_prompt = self.config.get("initial_prompt", None)
        else:
            initial_prompt = None
        try:
            context = self.retrieve_context(question=question)  #先检索
            prompt = self.construct_prompt(question=question, initial_prompt=initial_prompt, context=context)  #生成prompt
            step1_llm_response, sql = self.generate_sql(prompt=prompt)  #生成SQL
            if 'intermediate_sql' in step1_llm_response:
                self.log(title="Intermediate SQL", message=sql)
                df = self.run_sql(sql)
                intermediate_context = {
                    "question_sql_list": context.get("question_sql_list", []),
                    "ddl_list": context.get("ddl_list", []),
                    "doc_list": context.get("doc_list", []) + [
                        f"以下是包含中间SQL查询{sql}结果的pandas DataFrame：\n" + df.to_markdown()],
                }
                prompt = self.construct_prompt(question=question, initial_prompt=initial_prompt,
                                               context=intermediate_context)
                sql = self.generate_intermediate_sql(prompt=prompt, old_llm_response=step1_llm_response,
                                                     allow_llm_to_see_data=allow_llm_to_see_data)
        except Exception as e:
            self.log(title="[ask][Error]", message=str(e))
            return None, None, None
        if print_results:
            try:
                display = __import__(
                    "IPython.display", fromlist=["display"]
                ).display
                Code = __import__("IPython.display", fromlist=["Code"]).Code
                display(Code(sql))
            except Exception as e:
                self.log(title='[ask][Error]',message=str(e))
        if self.run_sql_is_set is False:
            self.log(title='[ask][Error]',message="如果要运行SQL查询，请先连接到数据库。")
            if print_results:
                return None
            else:
                return sql, None, None
        try:
            df = self.run_sql(sql)

            if print_results:
                try:
                    display = __import__(
                        "IPython.display", fromlist=["display"]
                    ).display
                    display(df)
                except Exception as e:
                    self.log(title="[ask][Error]", message=str(e))
            if len(df) > 0 and auto_train:
                self.add_question_sql(question, sql=sql)
            #仅当visualize为True时才生成plotly代码
            if visualize:
                try:
                    plotly_code = self.generate_plotly_code(
                        question=question,
                        sql=sql,
                        df_metadata=f"运行 df.dtypes 得到:\n {df.dtypes}",
                    )
                    fig = self.get_plotly_figure(plotly_code=plotly_code, df=df)
                    if print_results:
                        try:
                            display = __import__(
                                "IPython.display", fromlist=["display"]
                            ).display
                            Image = __import__(
                                "IPython.display", fromlist=["Image"]
                            ).Image
                            img_bytes = fig.to_image(format="png", scale=2)
                            display(Image(img_bytes))
                            fig.show()
                        except Exception as e:
                            fig.show()
                except Exception as e:
                    traceback.print_exc()
                    self.log(title='[ask][Error]',message="Couldn't run plotly code: "+str(e))
                    if print_results:
                        return None
                    else:
                        return sql, df, None
            else:
                return sql, df, None
        except Exception as e:
            self.log(title="[ask][Error]", message="运行不了SQL")
            if print_results:
                return None
            else:
                return sql, None, None
        return sql, df, fig

    def train(
            self,
            question: str = None,
            scene_name:str=None,
            sql: str = None,
            ddl: str = None,
            graph: str = None,
            documentation: list[str] = None,
            plan: TrainingPlan = None,
            exclude_field: list = None,
            chunk_size: int = 300,
    ) -> str | list[str]:
        """
        根据不同类型向向量库集合中存储向量
        :param scene_name: 场景名称
        :param chunk_size:
        :param exclude_field:
        :param question:
        :param sql:
        :param ddl:
        :param graph:
        :param documentation:
        :param plan:
        :return:
        """
        if question and not sql:
            raise ValidationError("Please also provide a SQL query")
        if scene_name and not ddl:
            raise ValidationError("Please also provide scene's DDL")
        if documentation:
            self.log(title='INFO',message="正在添加documentation....")
            chunks=self.chunk_text(documentation,chunk_size)
            id_lists=[]
            for chunk in chunks:
                id_lists.append(self.add_documentation(chunk))
            return id_lists
        #场景嵌入
        if scene_name:
            self.log(title='INFO',message="正在添加场景信息....")
            tables = self.__extract_info(ddl)
            for table in tables:
                embed = self.__create_embed(table, exclude_field)
                tableInfo = self.__create_tableInfo_prompt(table)
        #纯粹DDL嵌入
        if not scene_name and ddl:
            self.log(title='INFO',message="正在添加表结构信息....")
            if exclude_field is None:
                exclude_field = ['乐观锁版本', '创建时间', '数据更新时间', '数据来源', '省编码', '局编码']
            tables = self.__extract_info(ddl)
            id_list = []
            for table in tables:
                embed = self.__create_embed(table, exclude_field)
                tableInfo = self.__create_tableInfo_prompt(table)
                id_list.append(self.add_ddl(embed, tableInfo))
            return id_list

        if plan:
            for item in plan._plan:
                if item.item_type == TrainingPlanItem.ITEM_TYPE_SQL:
                    self.add_question_sql(question=item.item_name, sql=item.item_value)
                elif item.item_type == TrainingPlanItem.ITEM_TYPE_IS:
                    self.add_documentation(item.item_value)

    def get_plotly_figure(
            self, plotly_code: str, df: pd.DataFrame, dark_mode: bool = True
    ) -> plotly.graph_objs.Figure:
        """
        **Example:**
        ```python
        fig = get_plotly_figure(
            plotly_code="fig = px.bar(df, x='name', y='salary')",
            df=df
        )
        fig.show()
        ```
        Get a Plotly figure from a dataframe and Plotly code.

        Args:
            df (pd.DataFrame): The dataframe to use.
            plotly_code (str): The Plotly code to use.

        Returns:
            plotly.graph_objs.Figure: The Plotly figure.
        """
        ldict = {"df": df, "px": px, "go": go}
        try:
            exec(plotly_code, globals(), ldict)

            fig = ldict.get("fig", None)
        except Exception as e:
            # Inspect data types
            numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
            categorical_cols = df.select_dtypes(
                include=["object", "category"]
            ).columns.tolist()

            # Decision-making for plot type
            if len(numeric_cols) >= 2:
                # Use the first two numeric columns for a scatter plot
                fig = px.scatter(df, x=numeric_cols[0], y=numeric_cols[1])
            elif len(numeric_cols) == 1 and len(categorical_cols) >= 1:
                # Use a bar plot if there's one numeric and one categorical column
                fig = px.bar(df, x=categorical_cols[0], y=numeric_cols[0])
            elif len(categorical_cols) >= 1 and df[categorical_cols[0]].nunique() < 10:
                # Use a pie chart for categorical data with fewer unique values
                fig = px.pie(df, names=categorical_cols[0])
            else:
                # Default to a simple line plot if above conditions are not met
                fig = px.line(df)

        if fig is None:
            return None

        if dark_mode:
            fig.update_layout(template="plotly_dark")

        return fig


class LLMBase(GeoSQLBase):
    # def __init__(self, config=None):
    #     GeoSQLBase.__init__(self,config)
    @abstractmethod
    def system_message(self, message: str) -> any:
        pass

    @abstractmethod
    def user_message(self, message: str) -> any:
        pass

    @abstractmethod
    def assistant_message(self, message: str) -> any:
        pass

    @abstractmethod
    def extract_sql(self, llm_response):
        pass

    @abstractmethod
    def submit_prompt(self, prompt, **kwargs) -> str:
        pass

    @abstractmethod
    def frontend_generate_sql(self, prompt: str, stream: bool = True, **kwargs):
        pass

    def generate_embedding(self, data: str, **kwargs) -> List[float]:
        pass

    def chunk_text(self, text_list, chunk_size=300):
        """对documentation进行分块"""
        pass

    def add_question_sql(self, question: str, sql: str, **kwargs) -> str:
        pass

    def add_documentation(self, documentation: str, **kwargs) -> str:
        pass

    def add_ddl(self, ddl: str, tableInfo: str, **kwargs) -> str:
        pass

    def add_graph(self, graph: str, **kwargs) -> str:
        pass

    def get_training_data(self, **kwargs) -> pd.DataFrame:
        pass

    def remove_training_data(self, id: str, **kwargs) -> bool:
        pass

    def get_similar_question_sql(self, question: str, **kwargs) -> list:
        pass

    def get_related_documentation(self, question: str, **kwargs) -> list:
        pass

    def get_related_ddl(self, question: str, **kwargs) -> list:
        pass

    def retrieve_context(self, question: str, **kwargs) -> dict:
        pass


class RAGBase(GeoSQLBase):
    def __init__(self, config=None):
        GeoSQLBase.__init__(self, config)

    @abstractmethod
    def generate_embedding(self, data: str, **kwargs) -> List[float]:
        pass

    @abstractmethod
    def chunk_text(self, text_list, chunk_size=300):
        """对documentation进行分块"""
        pass
    @abstractmethod
    def add_question_sql(self, question: str, sql: str, **kwargs) -> str:
        pass

    @abstractmethod
    def add_documentation(self, documentation: str, **kwargs) -> str:
        pass

    @abstractmethod
    def add_ddl(self, ddl: str, tableInfo: str, **kwargs) -> str:
        pass

    @abstractmethod
    def add_graph(self, graph: str, **kwargs) -> str:
        pass

    @abstractmethod
    def get_training_data(self, **kwargs) -> pd.DataFrame:
        pass

    @abstractmethod
    def remove_training_data(self, id: str, **kwargs) -> bool:
        pass

    @abstractmethod
    def get_similar_question_sql(self, question: str, **kwargs) -> list:
        pass

    @abstractmethod
    def get_related_documentation(self, question: str, **kwargs) -> list:
        pass

    @abstractmethod
    def get_related_ddl(self, question: str, **kwargs) -> list:
        pass

    @abstractmethod
    def retrieve_context(self, question: str, **kwargs) -> dict:
        pass

    @abstractmethod
    def getCurrentRAGModel(self) -> str:
        pass

    def system_message(self, message: str) -> any:
        pass

    def user_message(self, message: str) -> any:
        pass

    def assistant_message(self, message: str) -> any:
        pass

    def extract_sql(self, llm_response):
        pass

    def submit_prompt(self, prompt, **kwargs) -> str:
        pass


    def frontend_generate_sql(self, prompt: str, stream: bool = True, **kwargs):
        pass
