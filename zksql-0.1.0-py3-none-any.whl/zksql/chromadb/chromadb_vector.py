import json

import pandas as pd

from ..base import RAGBase
from typing import List
import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from ..utils import deterministic_uuid

default_ef = embedding_functions.DefaultEmbeddingFunction()


class ChromaDB_VectorStore(RAGBase):
    def __init__(self, config=None):
        RAGBase.__init__(self, config)
        if config is None:
            config = {}

        path = config.get("path", ".")
        self.embedding_path = config.get("embedding_path", '')
        if self.embedding_path:
            self.embedding_name = config.get("embedding_name", '')
            self.embedding_function = SentenceTransformerEmbeddingFunction(model_name=self.embedding_path)
        else:
            self.embedding_function = config.get("embedding_function", default_ef)  #向量化函数
            self.embedding_name = config.get("embedding_name", 'default_ef')

        curr_client = config.get("client", "persistent")
        collection_metadata = config.get("collection_metadata", None)
        self.top_k_sql = config.get("top_k_sql", config.get("n_results", 10))
        self.top_k_ddl = config.get("top_k_ddl", config.get("n_results", 10))
        self.top_k_documentation = config.get("top_k_documentation", config.get("n_results", 10))

        if curr_client == "persistent":
            self.chroma_client = chromadb.PersistentClient(
                path=path, settings=Settings(anonymized_telemetry=False)
            )
        elif curr_client == "in-memory":
            self.chroma_client = chromadb.EphemeralClient(
                settings=Settings(anonymized_telemetry=False)
            )
        elif isinstance(curr_client, chromadb.api.client.Client):
            # allow providing client directly
            self.chroma_client = curr_client
        else:
            raise ValueError(f"Unsupported client was set in config: {curr_client}")

        #文档集合
        self.documentation_collection = self.chroma_client.get_or_create_collection(
            name="documentation",
            embedding_function=self.embedding_function,
            metadata=collection_metadata,
        )

        #表结构集合
        self.ddl_collection = self.chroma_client.get_or_create_collection(
            name="ddl",
            embedding_function=self.embedding_function,
            metadata=collection_metadata,
        )
        #sql集合
        self.sql_collection = self.chroma_client.get_or_create_collection(
            name="sql",
            embedding_function=self.embedding_function,
            metadata=collection_metadata,
        )
        #图rag集合
        self.graph_collection = self.chroma_client.get_or_create_collection(
            name="graph",
            embedding_function=self.embedding_function,
            metadata=collection_metadata,
        )

        #场景集合
        self.scene_collection=self.chroma_client.get_or_create_collection(
            name="graph",
            embedding_function=self.embedding_function,
            metadata=collection_metadata,
        )

    def generate_embedding(self, data: str, **kwargs) -> List[float]:
        """
        生成文本向量
        :param data:
        :param kwargs:
        :return:
        """
        embedding = self.embedding_function([data])
        if len(embedding) == 1:
            return embedding[0]
        return embedding

    def chunk_text(self, text_list, chunk_size=300):
        """对documentation进行分块"""
        chunks = []
        current_chunk = ""
        for line in text_list:
            if len(current_chunk) + len(line) > chunk_size:
                chunks.append(current_chunk.strip())
                current_chunk = line
            else:
                current_chunk += " " + line
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        return chunks

    def add_question_sql(self, question: str, sql: str, **kwargs) -> str:
        """
        向向量库中添加question-sql对向量
        :param question:
        :param sql:
        :param kwargs:
        :return:
        """
        question_sql_json = json.dumps(
            {
                "question": question,
                "sql": sql,
            },
            ensure_ascii=False,
        )
        id = deterministic_uuid(question_sql_json) + "-sql"
        self.sql_collection.add(
            documents=question_sql_json,
            embeddings=self.generate_embedding(question_sql_json),
            ids=id,
        )

        return id

    def add_documentation(self, documentation: str, **kwargs) -> str:
        """
        向向量库中添加文档向量
        :param documentation:
        :param kwargs:
        :return:
        """
        id = deterministic_uuid(documentation) + "-doc"
        self.documentation_collection.add(
            documents=documentation,
            embeddings=self.generate_embedding(documentation),
            ids=id,
        )
        return id

    def add_ddl(self, ddl: str, tableInfo: str, **kwargs) -> str:
        """
        向向量库中添加表描述信息的向量
        :param tableInfo:
        :param ddl:
        :param kwargs:
        :return:
        """
        id = deterministic_uuid(ddl) + "-ddl"

        self.ddl_collection.add(
            documents=tableInfo,
            embeddings=self.generate_embedding(ddl),
            ids=id,
        )
        return id

    def add_graph(self, graph: str, **kwargs) -> str:
        return ''

    def add_scene(self,scene_name:str, ddl,**kwargs)->str:
        pass
    def get_training_data(self, **kwargs) -> pd.DataFrame:
        """
        获得训练的向量数据
        :param kwargs:
        :return:
        """
        sql_data = self.sql_collection.get()

        df = pd.DataFrame()

        if sql_data is not None:
            # Extract the documents and ids
            documents = [json.loads(doc) for doc in sql_data["documents"]]
            ids = sql_data["ids"]

            # Create a DataFrame
            df_sql = pd.DataFrame(
                {
                    "id": ids,
                    "question": [doc["question"] for doc in documents],
                    "content": [doc["sql"] for doc in documents],
                }
            )

            df_sql["training_data_type"] = "sql"

            df = pd.concat([df, df_sql])

        doc_data = self.documentation_collection.get()

        if doc_data is not None:
            # Extract the documents and ids
            documents = [doc for doc in doc_data["documents"]]
            ids = doc_data["ids"]

            # Create a DataFrame
            df_doc = pd.DataFrame(
                {
                    "id": ids,
                    "question": [None for doc in documents],
                    "content": [doc for doc in documents],
                }
            )

            df_doc["training_data_type"] = "documentation"

            df = pd.concat([df, df_doc])

        return df

    def remove_training_data(self, id: str, **kwargs) -> bool:
        """
        移除训练的向量
        :param id:
        :param kwargs:
        :return:
        """
        if id.endswith("-sql"):
            self.sql_collection.delete(ids=id)
            return True
        elif id.endswith("-ddl"):
            self.ddl_collection.delete(ids=id)
            return True
        elif id.endswith("-doc"):
            self.documentation_collection.delete(ids=id)
            return True
        else:
            return False

    def remove_collection(self, collection_name: str) -> bool:
        """
        This function can reset the collection to empty state.

        Args:
            collection_name (str): sql or ddl or documentation

        Returns:
            bool: True if collection is deleted, False otherwise
        """
        if collection_name == "sql":
            self.chroma_client.delete_collection(name="sql")
            self.sql_collection = self.chroma_client.get_or_create_collection(
                name="sql", embedding_function=self.embedding_function
            )
            return True
        elif collection_name == "ddl":
            self.chroma_client.delete_collection(name="ddl")
            self.ddl_collection = self.chroma_client.get_or_create_collection(
                name="ddl", embedding_function=self.embedding_function
            )
            return True
        elif collection_name == "documentation":
            self.chroma_client.delete_collection(name="documentation")
            self.documentation_collection = self.chroma_client.get_or_create_collection(
                name="documentation", embedding_function=self.embedding_function
            )
            return True
        else:
            return False

    @staticmethod
    def _extract_documents(query_results) -> list:
        """
        从查询结果中提取出文档内容，并兼容处理嵌套列表、JSON 字符串等情况。
        :param query_results:
        :return:
        """
        if query_results is None:
            return []

        if "documents" in query_results:
            documents = query_results["documents"]
            if len(documents) == 1 and isinstance(documents[0], list):
                try:
                    documents = [json.loads(doc) for doc in documents[0]]
                except Exception as e:
                    return documents[0]

            return documents

    def get_similar_question_sql(self, question: str, **kwargs) -> list:
        return ChromaDB_VectorStore._extract_documents(
            self.sql_collection.query(
                query_texts=[question],
                n_results=self.top_k_sql,
            )
        )

    def get_related_documentation(self, question: str, **kwargs) -> list:
        return ChromaDB_VectorStore._extract_documents(
            self.documentation_collection.query(
                query_texts=[question],
                n_results=self.top_k_documentation,
            )
        )

    def get_related_ddl(self, question: str, **kwargs) -> list:
        return ChromaDB_VectorStore._extract_documents(
            self.ddl_collection.query(
                query_texts=[question],
                n_results=self.top_k_ddl,
            )
        )

    def retrieve_context(self, question: str, **kwargs) -> dict:
        return {
            "question_sql_list": self.get_similar_question_sql(question=question, **kwargs),
            "ddl_list": self.get_related_ddl(question=question, **kwargs),
            "doc_list": self.get_related_documentation(question=question, **kwargs),
        }

    # 获取当前RAG检索模型
    def getCurrentRAGModel(self) -> str:
        return self.embedding_name
