import json
import re
from ..base import LLMBase
from ..exceptions import DependencyError


class GPTAPI(LLMBase):
    def __init__(self, config=None):
        try:
            from openai import OpenAI

        except ImportError:
            raise DependencyError(
                "To execute this method, you need to install the required dependencies, run the following command:"
                " \npip install openai"
            )
        try:
            self.api_key = config.get('api_key')
        except Exception as e:
            raise "API Key not passed in"
        try:
            self.base_url = config.get('base_url')
        except Exception as e:
            raise "base_url not passeds"
        try:
            self.model = config.get('model')
        except Exception as e:
            raise "Model not passed in"
        self.gpt = OpenAI(api_key=self.api_key, base_url=self.base_url)
        self.gpt_options = config.get('options', {})
        self.keep_alive = config.get('keep_alive', None)
        self.num_ctx=config.get('num_ctx',2048)

    def update_llm(self,config):
        try:
            from openai import OpenAI

        except ImportError:
            raise DependencyError(
                "To execute this method, you need to install the required dependencies, run the following command:"
                " \npip install openai"
            )
        self.api_key = config.get('api_key')
        self.base_url = config.get('base_url')
        self.model = config.get('model')
        self.gpt = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def system_message(self, message: str) -> any:
        """
        系统角色
        :param message: 请求信息
        :return:
        """
        return {"role": "system", "content": message}

    def user_message(self, message: str) -> any:
        """
        用户角色
        :param message:
        :return:
        """
        return {"role": "user", "content": message}

    def assistant_message(self, message: str) -> any:
        """
        助理角色
        :param message:
        :return:
        """
        return {"role": "assistant", "content": message}

    def extract_sql(self, llm_response):
        """
        从LLM返回语句中提取SQL
        :param llm_response:LLM返回信息
        :return: 找到的第一个 SQL 语句，删除三个反引号，如果未找到匹配项，则为空字符串。
        """

        # 删除ollama生成的多余字符
        # 清理 Ollama 中的特殊字符
        llm_response = llm_response.replace("\\_", "_").replace("\\", "")

        # 1. 优先匹配 ```sql ... ``` 块
        sql_block = re.search(r"```sql\s*\n(.*?)```", llm_response, re.DOTALL | re.IGNORECASE)

        if sql_block:
            return sql_block.group(1).strip()
        # 2. 其次尝试匹配 select/with 开头的 SQL，直到换行 + 空行 + 下一段文字或结束
        select_match = re.search(r"\b(select|with)\b[\s\S]{10,}?(?=\n\s*\n|$)", llm_response, re.IGNORECASE)

        if select_match:
            return select_match.group(0).strip()
        # 3. fallback：返回整体文本（不建议用于正式执行）
        return llm_response.strip()

    def submit_prompt(self, prompt, **kwargs) -> str:
        temperature=kwargs.get('temperature',0)
        max_tokens = kwargs.get('max_tokens', self.num_ctx)
        top_p=kwargs.get('top_p',1.0)
        frequency_penalty=kwargs.get('frequency_penalty',0.0)
        presence_penalty=kwargs.get('presence_penalty',0.0)
        self.log(
            f"Model Parameters:\n"
            f"model={self.model},\n"
            f"options={self.gpt_options},\n"
            f"keep_alive={self.keep_alive}")
        try:
            response = self.gpt.chat.completions.create(
                model=self.model,  # 指定模型
                messages=prompt,  # 传入对话历史
                temperature=temperature,  # 随机性控制，越高越creative
                max_tokens=max_tokens,  # 回复最长token数
                top_p=top_p,  # nucleus sampling
                frequency_penalty=frequency_penalty,  # 频率惩罚，控制重复
                presence_penalty=presence_penalty,  # 新话题惩罚，控制拓展
                stream=False
            )
        except Exception as e:
            raise e
        try:
            reply_content = response.choices[0].message.content
        except Exception as e:
            self.log(title='[submit_prompt][error]',message=str(e))
        return reply_content

    def frontend_generate_sql(self, prompt: str, **kwargs):
        temperature=kwargs.get('temperature',0)
        max_tokens = kwargs.get('max_tokens', 1028)
        top_p=kwargs.get('top_p',1.0)
        frequency_penalty=kwargs.get('frequency_penalty',0.0)
        presence_penalty=kwargs.get('presence_penalty',0.0)
        self.log(
            f"Model Parameters:\n"
            f"model={self.model},\n"
            f"options={self.gpt_options},\n"
            f"keep_alive={self.keep_alive}")
        try:
            response = self.gpt.chat.completions.create(
                model=self.model,  # 指定模型
                messages=prompt,  # 传入对话历史
                temperature=temperature,  # 随机性控制，越高越creative
                max_tokens=max_tokens,  # 回复最长token数
                top_p=top_p,  # nucleus sampling
                frequency_penalty=frequency_penalty,  # 频率惩罚，控制重复
                presence_penalty=presence_penalty,  # 新话题惩罚，控制拓展
                stream=True
            )
            buffer = ""
            for chunk in response:
                if not chunk.choices:
                    continue  # 跳过空数据
                content = chunk.choices[0].delta.content or ""
                buffer += content
                if len(buffer) >= 10:  # 只有在积累到 10 个字符后才发送
                    # SSE 格式要求 data: 前缀和双换行符
                    yield f"data: {json.dumps({'content': buffer})}\n\n"
                    buffer = ""
            if buffer:
                yield f"data: {json.dumps({'content': buffer})}\n\n"
        except Exception as e:
            self.log(title="[frontend_generate_sql][Error]", message=str(e))
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
